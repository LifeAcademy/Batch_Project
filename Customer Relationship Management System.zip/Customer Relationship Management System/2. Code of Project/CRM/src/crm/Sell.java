
package crm;
import java.io.*;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.JMenu;
import java.awt.Font;
import java.awt.Color;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Sell extends javax.swing.JFrame {

   
    public Sell() {
        setTitle("SELL A PRODUCT");
        Date d=new Date();
        initComponents();
        jLabel6.setText(d.toString());
    }

   
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel1.setForeground(UIManager.getColor("Button.background"));
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenu3.setForeground(Color.BLACK);
        jMenu3.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu4 = new javax.swing.JMenu();
        jMenu4.setForeground(Color.BLACK);
        jMenu4.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu5 = new javax.swing.JMenu();
        jMenu5.setForeground(Color.BLACK);
        jMenu5.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu6 = new javax.swing.JMenu();
        jMenu6.setForeground(Color.BLACK);
        jMenu6.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu1 = new javax.swing.JMenu();
        jMenu1.setForeground(Color.BLACK);
        jMenu1.setFont(new Font("Segoe UI", Font.BOLD, 15));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                formMouseMoved(evt);
            }
        });

        jPanel1.setBackground(new Color(0, 102, 204));

        jLabel1.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CUSTOMER NAME");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("PRODUCT ID");

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PRODUCT NAME");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("TODAY's DATE");

        jLabel6.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jLabel6MouseMoved(evt);
            }
        });
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel6MouseEntered(evt);
            }
        });

        jLabel4.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("WARRANTY (In Days)");

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });

        jButton1.setBackground(UIManager.getColor("Button.background"));
        jButton1.setFont(new Font("Arial Black", Font.BOLD, 22)); 
        jButton1.setForeground(new Color(0, 0, 0));
        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        
        
        
        JButton btnlogout = new JButton("LOGOUT");
        btnlogout.setBackground(UIManager.getColor("Button.background"));
        btnlogout.setFont(new Font("Arial Black", Font.BOLD, 22));
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(365)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        								.addComponent(jLabel2)
        								.addComponent(jLabel1)
        								.addComponent(jLabel3)
        								.addComponent(jLabel5))
        							.addGap(196))
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addComponent(jLabel4, GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE)
        							.addPreferredGap(ComponentPlacement.RELATED))))
        				.addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
        					.addContainerGap()
        					.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
        					.addGap(192)))
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addComponent(jLabel6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        							.addGap(256))
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addComponent(jTextField4, GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
        							.addGap(329))
        						.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 260, GroupLayout.PREFERRED_SIZE)
        						.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING, false)
        							.addComponent(jTextField3, Alignment.LEADING)
        							.addComponent(jTextField2, Alignment.LEADING, 260, 260, Short.MAX_VALUE)))
        					.addGap(0))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addComponent(btnlogout, GroupLayout.PREFERRED_SIZE, 156, GroupLayout.PREFERRED_SIZE)
        					.addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(55)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel1))
        			.addGap(67)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel2))
        			.addGap(66)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel3))
        			.addGap(84)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jLabel6, GroupLayout.PREFERRED_SIZE, 25, Short.MAX_VALUE)
        				.addComponent(jLabel5, GroupLayout.PREFERRED_SIZE, 19, Short.MAX_VALUE))
        			.addGap(74)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        				.addComponent(jTextField4, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel4))
        			.addGap(82)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(btnlogout, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE))
        			.addGap(104))
        );
        jPanel1.setLayout(jPanel1Layout);

        jMenu3.setText("HOME");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu3);

        jMenu4.setText("Sell Product");
        jMenu4.addMenuKeyListener(new javax.swing.event.MenuKeyListener() {
            public void menuKeyPressed(javax.swing.event.MenuKeyEvent evt) {
                jMenu4MenuKeyPressed(evt);
            }
            public void menuKeyReleased(javax.swing.event.MenuKeyEvent evt) {
            }
            public void menuKeyTyped(javax.swing.event.MenuKeyEvent evt) {
            }
        });
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
        });
        
        mnNewMenu = new JMenu("");
        jMenuBar1.add(mnNewMenu);
        
        mnNewMenu_5 = new JMenu("");
        jMenuBar1.add(mnNewMenu_5);
        jMenuBar1.add(jMenu4);

        jMenu5.setText("Product Details");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        
        mnNewMenu_1 = new JMenu("");
        jMenuBar1.add(mnNewMenu_1);
        
        mnNewMenu_4 = new JMenu("");
        jMenuBar1.add(mnNewMenu_4);
        jMenuBar1.add(jMenu5);

        jMenu6.setText("Customer Details");
        jMenu6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu6MouseClicked(evt);
            }
        });
        
        mnNewMenu_2 = new JMenu("");
        jMenuBar1.add(mnNewMenu_2);
        
        mnNewMenu_6 = new JMenu("");
        jMenuBar1.add(mnNewMenu_6);
        jMenuBar1.add(jMenu6);

        jMenu1.setText("Add  Product");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        
        mnNewMenu_3 = new JMenu("");
        jMenuBar1.add(mnNewMenu_3);
        
        mnNewMenu_7 = new JMenu("");
        jMenuBar1.add(mnNewMenu_7);
        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 1367, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 733, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        getContentPane().setLayout(layout);

        pack();
    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
        
    }
    
    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {
       
       
    	this.setVisible(false);
        this.dispose();
        Login frame = new Login();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true); 	
    	
        }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        
    try
    {
    	String driverclass="com.mysql.cj.jdbc.Driver";
		String connectionURL="jdbc:mysql://localhost:3306/crm";
		String username="root";
		String password="Deepchand@123";
		
		
		Class.forName(driverclass);
		Connection con = DriverManager.getConnection(connectionURL, username, password);
		
        System.out.println(con.toString());
        String nm=jTextField1.getText();
        int id=Integer.parseInt(jTextField2.getText());
        String Prod_nm=jTextField3.getText();
        java.util.Date de = new java.util.Date();

        java.text.SimpleDateFormat sdf = 
            new java.text.SimpleDateFormat("yyyy-MM-dd");

        String currentTime = sdf.format(de);
        System.out.println(currentTime);

        int warr=Integer.parseInt(jTextField4.getText());
            
            
        String query1 = "SELECT Count FROM products WHERE ID='"+id +"' AND Name='"+Prod_nm +"';";

        System.out.println("Query :" + query1);
        Statement st1 = con.createStatement();
        ResultSet rs1 = st1.executeQuery(query1);
        int flag = 1;
        while (rs1.next())
        {
            int count = rs1.getInt("Count");
            if (count <= 0)
            {
                JOptionPane.showMessageDialog(this,"Product out of stock" );
                flag = 0;
            }
        }
        
        if (flag == 1)
        {
            String query = "INSERT INTO crm.products_sold (Customer_name,Product_id,warranty,product_name,date)VALUES(" + "\"" + nm + "\"" + "," + id + "," + warr + "," + "\""+Prod_nm+"\"" + "," + "\"" + currentTime+"\"" + ");";
            System.out.println("Query :" + query);
            Statement st = con.createStatement();
            int val = st.executeUpdate(query);
            
            String query2 = "UPDATE products SET Count = Count - 1 WHERE id = '"+id +"';";
            System.out.println("Query :" + query2);
            Statement st2 = con.createStatement();
            int val2 = st2.executeUpdate(query2);
          
            
            if (val > 0)
            {
                JOptionPane.showMessageDialog(this,"Product sold successfully" );
            }
            con.close();
        }
    }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(this,"Error in connectivity" );
    }  
    }

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {
       
    }

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {
      
    }

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {
       
    }

    private void jLabel6MouseEntered(java.awt.event.MouseEvent evt) {
      
    }

    private void jLabel6MouseMoved(java.awt.event.MouseEvent evt) {
       
    }

    private void formMouseMoved(java.awt.event.MouseEvent evt) {
      

    }

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        Home frame = new Home();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu4MenuKeyPressed(javax.swing.event.MenuKeyEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        Sell frame = new Sell();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {
       
        Product_details frame = new Product_details();
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu6MouseClicked(java.awt.event.MouseEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        customer_details frame = new customer_details();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }
    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        Add_product frame = new Add_product();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        Sell frame = new Sell();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }

   
    public static void main(String args[]) {
      
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sell.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sell().setVisible(true);
            }
        });
    }

    
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private JMenu mnNewMenu;
    private JMenu mnNewMenu_1;
    private JMenu mnNewMenu_2;
    private JMenu mnNewMenu_3;
    private JMenu mnNewMenu_4;
    private JMenu mnNewMenu_5;
    private JMenu mnNewMenu_6;
    private JMenu mnNewMenu_7;
}
