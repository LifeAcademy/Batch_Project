
package crm;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JMenu;
import javax.swing.UIManager;
import javax.swing.JLabel;
import javax.swing.JButton;



public class customer_details extends javax.swing.JFrame {

    
    public static String name;
    public static String date;
    public customer_details() {
        initComponents();
        setTitle("Customer Details");
    }

   
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu1.setForeground(UIManager.getColor("Button.focus"));
        jMenu1.setBackground(UIManager.getColor("Button.focus"));
        jMenu1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu2 = new javax.swing.JMenu();
        jMenu2.setForeground(UIManager.getColor("Button.focus"));
        jMenu2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu3 = new javax.swing.JMenu();
        jMenu3.setForeground(UIManager.getColor("Button.focus"));
        jMenu3.setBackground(UIManager.getColor("Button.focus"));
        jMenu3.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu4 = new javax.swing.JMenu();
        jMenu4.setForeground(UIManager.getColor("Button.focus"));
        jMenu4.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu5 = new javax.swing.JMenu();
        jMenu5.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu5.setForeground(UIManager.getColor("Button.focus"));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new Color(0, 102, 204));

        jLabel1.setFont(new Font("Arial Black", Font.BOLD, 27));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CUSTOMER NAME");

        jLabel2.setFont(new Font("Arial Black", Font.BOLD, 27)); 
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("DATE OF PURCHASE (YYYY-MM-DD) ");

        jButton1.setBackground(UIManager.getColor("Button.background"));
        jButton1.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jButton1.setForeground(new Color(0, 0, 0));
        jButton1.setText("GET CUSTOMER DETAILS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        
        JButton btnlogout = new JButton("LOGOUT");
        btnlogout.setFont(new Font("Arial Black", Font.BOLD, 25));
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });
       
        lblNewLabel = new JLabel("GET DETAILS OF EXISTING CUSTOMER");
        lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 25));
        
        

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(142)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 423, GroupLayout.PREFERRED_SIZE)
        						.addComponent(jLabel2)))
        				.addGroup(Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
        					.addContainerGap(312, Short.MAX_VALUE)
        					.addComponent(jButton1)
        					.addGap(107)))
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(108)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING, false)
        						.addComponent(jTextField2)
        						.addComponent(jTextField1, GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(145)
        					.addComponent(btnlogout, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)))
        			.addContainerGap(295, Short.MAX_VALUE))
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(346)
        			.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        			.addGap(618))
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(90)
        			.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 34, Short.MAX_VALUE)
        			.addGap(89)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        				.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel1))
        			.addGap(100)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel2))
        			.addGap(122)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        				.addComponent(btnlogout, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE))
        			.addGap(133))
        );
        jPanel1.setLayout(jPanel1Layout);

        jMenu1.setText("HOME");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Sell Product");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        
        mnNewMenu = new JMenu("");
        jMenuBar1.add(mnNewMenu);
        
        mnNewMenu_1 = new JMenu("");
        jMenuBar1.add(mnNewMenu_1);
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Product Details");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        
        mnNewMenu_2 = new JMenu("");
        jMenuBar1.add(mnNewMenu_2);
        
        mnNewMenu_3 = new JMenu("");
        jMenuBar1.add(mnNewMenu_3);
        jMenuBar1.add(jMenu3);

        jMenu4.setText("Customer Details");
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
        });
        
        mnNewMenu_4 = new JMenu("");
        jMenuBar1.add(mnNewMenu_4);
        
        mnNewMenu_5 = new JMenu("");
        jMenuBar1.add(mnNewMenu_5);
        jMenuBar1.add(jMenu4);

        jMenu5.setText("Add  Product");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        
        mnNewMenu_9 = new JMenu("");
        jMenuBar1.add(mnNewMenu_9);
        
        mnNewMenu_10 = new JMenu("");
        jMenuBar1.add(mnNewMenu_10);
        
        mnNewMenu_8 = new JMenu("");
        jMenuBar1.add(mnNewMenu_8);
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(Alignment.TRAILING, layout.createSequentialGroup()
        			.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, 1525, Short.MAX_VALUE)
        			.addContainerGap())
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, 706, Short.MAX_VALUE))
        );
        getContentPane().setLayout(layout);

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        
        name = jTextField1.getText();
        date = jTextField2.getText();
        customer_details_table frame = new customer_details_table();
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {
        
        this.setVisible(false);
        this.dispose();
        Home frame = new Home();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);        
    }

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {
      
        this.setVisible(false);
        this.dispose();
        Sell frame = new Sell();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {
      
        Product_details frame = new Product_details();
        frame.pack();
        frame.setVisible(true);        
    }

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        customer_details frame = new customer_details();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);       
    }

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {
        
        this.setVisible(false);
        this.dispose();
        Add_product frame = new Add_product();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);        
    }
    
    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {
       
    	this.setVisible(false);
        this.dispose();
        Login frame = new Login();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true); 	
    	
        }

   
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(customer_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(customer_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(customer_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(customer_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new customer_details().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private JMenu mnNewMenu;
    private JMenu mnNewMenu_1;
    private JMenu mnNewMenu_2;
    private JMenu mnNewMenu_3;
    private JMenu mnNewMenu_4;
    private JMenu mnNewMenu_5;
    private JMenu mnNewMenu_8;
    private JMenu mnNewMenu_9;
    private JMenu mnNewMenu_10;
    private JLabel lblNewLabel;
    private JButton btnlogout;
}

class customer_details_table extends javax.swing.JFrame {

    /**
     * Creates new form customer_details_table
     */
    
    public customer_details_table() {
        setTitle("Products Details");
        ArrayList columnNames = new ArrayList();
        ArrayList data = new ArrayList();
        try
        {
            customer_details demo = new customer_details();
            System.out.println(demo.name+ " " + demo.date);
            String driver = "com.mysql.jdbc.Driver";
            Class.forName(driver);
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crm", "root", "Deepchand@123");
            System.out.println(con.toString());
            String sql = "SELECT * FROM products_sold WHERE Customer_name='"+demo.name+"' AND date='"+demo.date+"';";
            System.out.println(sql);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery( sql );

            ResultSetMetaData md = rs.getMetaData();
            int columns = md.getColumnCount();

            //  Get column names
            for (int i = 1; i <= columns; i++)
            {
                columnNames.add( md.getColumnName(i) );
            }

            //  Get row data
            while (rs.next())
            {
                ArrayList row = new ArrayList(columns);

                for (int i = 1; i <= columns; i++)
                {
                    row.add( rs.getObject(i) );
                }

                data.add( row );
            }

            Vector columnNamesVector = new Vector();
            Vector dataVector = new Vector();

            for (int i = 0; i < data.size(); i++)
            {
                ArrayList subArray = (ArrayList)data.get(i);
                Vector subVector = new Vector();
                for (int j = 0; j < subArray.size(); j++)
                {
                    subVector.add(subArray.get(j));
                }
                dataVector.add(subVector);
            }

            for (int i = 0; i < columnNames.size(); i++ )
                columnNamesVector.add(columnNames.get(i));

            //  Create table with database data    
            JTable table = new JTable(dataVector, columnNamesVector)
            {
                public Class getColumnClass(int column)
                {
                    for (int row = 0; row < getRowCount(); row++)
                    {
                        Object o = getValueAt(row, column);

                        if (o != null)
                        {
                            return o.getClass();
                        }
                    }

                    return Object.class;
                }
            };

            JScrollPane scrollPane = new JScrollPane( table );
            getContentPane().add( scrollPane );

            JPanel buttonPanel = new JPanel();
            getContentPane().add( buttonPanel, BorderLayout.SOUTH );
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(this,"Error in connectivity" );
        }      
    }
}
