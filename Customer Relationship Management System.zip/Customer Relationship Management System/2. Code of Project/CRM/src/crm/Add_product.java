
package crm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.GroupLayout;
import java.awt.Font;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JMenu;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Add_product extends javax.swing.JFrame {

   
    public Add_product() {
        setTitle("ADD A PRODUCT");
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel4.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel4.setBackground(UIManager.getColor("Button.focus"));
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu1.setForeground(UIManager.getColor("Button.focus"));
        jMenu1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu2 = new javax.swing.JMenu();
        jMenu2.setForeground(UIManager.getColor("Button.focus"));
        jMenu2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu3 = new javax.swing.JMenu();
        jMenu3.setForeground(UIManager.getColor("Button.focus"));
        jMenu3.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu4 = new javax.swing.JMenu();
        jMenu4.setForeground(UIManager.getColor("Button.focus"));
        jMenu4.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jMenu5 = new javax.swing.JMenu();
        jMenu5.setForeground(UIManager.getColor("Button.focus"));
        jMenu5.setFont(new Font("Segoe UI", Font.BOLD, 15));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new Color(0, 102, 204));

        jLabel1.setBackground(new java.awt.Color(0, 153, 204));
        jLabel1.setFont(new Font("Arial Black", Font.BOLD, 30)); 
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PRODUCT ID");

        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 18)); 
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(0, 153, 204));
        jLabel2.setFont(new Font("Arial Black", Font.BOLD, 30)); 
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("PRODUCT NAME");

        jTextField2.setFont(new java.awt.Font("Tahoma", 0, 18)); 

        jLabel3.setBackground(new java.awt.Color(0, 153, 204));
        jLabel3.setFont(new Font("Arial Black", Font.BOLD, 30)); 
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("PRODUCT QUANTITY");

        jTextField3.setFont(new java.awt.Font("Tahoma", 0, 18)); 

        jButton1.setBackground(UIManager.getColor("Button.background"));
        jButton1.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jButton1.setForeground(UIManager.getColor("Button.focus"));
        jButton1.setText("ADD TO STOCK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new Font("Arial Black", Font.BOLD, 20)); 
        jLabel4.setForeground(UIManager.getColor("Button.focus"));
        jLabel4.setText(" If the product does not exist it will be created with the above details");
        
        JLabel lblNewLabel = new JLabel("ADD PRODUCTS TO OUR STOCK");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 24));
        
        btnlogout = new JButton("LOGOUT");
        btnlogout.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        JButton btnlogout = new JButton("LOGOUT");
        btnlogout.setFont(new Font("Arial Black", Font.BOLD, 25));
        btnlogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1Layout.setHorizontalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(184)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        						.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        							.addComponent(jLabel3)
        							.addComponent(jLabel2)
        							.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 298, GroupLayout.PREFERRED_SIZE))
        						.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 232, GroupLayout.PREFERRED_SIZE))
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addGap(108)
        							.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING, false)
        								.addComponent(jTextField3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 543, Short.MAX_VALUE)
        								.addComponent(jTextField2)
        								.addComponent(jTextField1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 574, Short.MAX_VALUE)))
        						.addGroup(jPanel1Layout.createSequentialGroup()
        							.addGap(345)
        							.addComponent(btnlogout, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE))))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGap(339)
        					.addComponent(jLabel4))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addContainerGap()
        					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 1422, GroupLayout.PREFERRED_SIZE)))
        			.addContainerGap(233, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
        	jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        		.addGroup(jPanel1Layout.createSequentialGroup()
        			.addGap(57)
        			.addComponent(lblNewLabel)
        			.addPreferredGap(ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addComponent(jTextField1, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
        				.addComponent(jLabel1, GroupLayout.PREFERRED_SIZE, 56, GroupLayout.PREFERRED_SIZE))
        			.addGap(47)
        			.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
        						.addComponent(jLabel2)
        						.addComponent(jTextField2, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE))
        					.addGap(46)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
        						.addComponent(jTextField3, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
        						.addComponent(jLabel3, GroupLayout.PREFERRED_SIZE, 62, GroupLayout.PREFERRED_SIZE))
        					.addPreferredGap(ComponentPlacement.RELATED, 193, Short.MAX_VALUE)
        					.addComponent(jLabel4)
        					.addGap(37))
        				.addGroup(jPanel1Layout.createSequentialGroup()
        					.addPreferredGap(ComponentPlacement.RELATED, 215, Short.MAX_VALUE)
        					.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
        						.addComponent(jButton1, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
        						.addComponent(btnlogout, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE))
        					.addGap(140))))
        );
        jPanel1.setLayout(jPanel1Layout);

        jMenu1.setText("HOME");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Sell Product");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        
        mnNewMenu = new JMenu("");
        jMenuBar1.add(mnNewMenu);
        
        mnNewMenu_4 = new JMenu("");
        jMenuBar1.add(mnNewMenu_4);
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Product Details");
        jMenu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu3MouseClicked(evt);
            }
        });
        
        mnNewMenu_1 = new JMenu("");
        jMenuBar1.add(mnNewMenu_1);
        
        mnNewMenu_5 = new JMenu("");
        jMenuBar1.add(mnNewMenu_5);
        jMenuBar1.add(jMenu3);

        jMenu4.setText("Customer Details");
        jMenu4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu4MouseClicked(evt);
            }
        });
        
        mnNewMenu_2 = new JMenu("");
        jMenuBar1.add(mnNewMenu_2);
        
        mnNewMenu_6 = new JMenu("");
        jMenuBar1.add(mnNewMenu_6);
        jMenuBar1.add(jMenu4);

        jMenu5.setText("Add Product");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        
        mnNewMenu_7 = new JMenu("");
        jMenuBar1.add(mnNewMenu_7);
        
        mnNewMenu_3 = new JMenu("");
        jMenuBar1.add(mnNewMenu_3);
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 1665, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(204, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(layout.createSequentialGroup()
        			.addGap(5)
        			.addComponent(jPanel1, GroupLayout.PREFERRED_SIZE, 717, Short.MAX_VALUE))
        );
        getContentPane().setLayout(layout);

        pack();
    }

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {
       
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
       
        
        try
        {
        	String driverclass="com.mysql.cj.jdbc.Driver";
			String connectionURL="jdbc:mysql://localhost:3306/crm";
			String username="root";
			String password="Deepchand@123";
			
			
			Class.forName(driverclass);
			Connection con = DriverManager.getConnection(connectionURL, username, password);
            
            
            System.out.println(con.toString());
            int id=Integer.parseInt(jTextField1.getText());
            String Prod_nm=jTextField2.getText();
            int incre = Integer.parseInt(jTextField3.getText());
            
            //String query = "UPDATE products SET Count = Count + '"+incre +"' WHERE id = '"+id +"' AND Name = '"+Prod_nm +"' ;";
            
            String query = "UPDATE products SET Count = Count + '"+incre +"' WHERE ID = '"+id +"' AND Name = '"+Prod_nm +"' ;";
            
           
            
            
            System.out.println("Query :" + query);
            Statement st = con.createStatement();
            int val = st.executeUpdate(query);
            System.out.println(val);
            if (val > 0)
                JOptionPane.showMessageDialog(this,"Products added successfully" );
            
            else if (val == 0)
            {
                query = "INSERT INTO crm.products (`ID`, `Name`, `Count`) VALUES ('"+id +"', '"+Prod_nm +"', '"+incre +"');";
                System.out.println("Query :" + query);
                st = con.createStatement();
                val = st.executeUpdate(query);
                if (val > 0)
                    JOptionPane.showMessageDialog(this,"Brand new Product added successfully" );
            }
            con.close();
        
        }
        
        catch(Exception e)
        {
           
        	e.printStackTrace();
        }  
    }

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {
        
        this.setVisible(false);
        this.dispose();
        Home frame = new Home();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {
        
        this.setVisible(false);
        this.dispose();
        Sell frame = new Sell();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);        
    }

    private void jMenu3MouseClicked(java.awt.event.MouseEvent evt) {
        
        Product_details frame = new Product_details();
        frame.pack();
        frame.setVisible(true);        
    }

    private void jMenu4MouseClicked(java.awt.event.MouseEvent evt) {
        
        this.setVisible(false);
        this.dispose();
        customer_details frame = new customer_details();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);        
    }

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {
       
        this.setVisible(false);
        this.dispose();
        Add_product frame = new Add_product();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);        
    }
    
    private void btnlogoutActionPerformed(java.awt.event.ActionEvent evt) {
      
       
    	this.setVisible(false);
        this.dispose();
        Login frame = new Login();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true); 	
    	
        }

    
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Add_product.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Add_product.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Add_product.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Add_product.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Add_product().setVisible(true);
            }
        });
    }

 
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private JMenu mnNewMenu;
    private JMenu mnNewMenu_1;
    private JMenu mnNewMenu_2;
    private JMenu mnNewMenu_3;
    private JMenu mnNewMenu_4;
    private JMenu mnNewMenu_5;
    private JMenu mnNewMenu_6;
    private JMenu mnNewMenu_7;
    private JButton btnlogout;
}
