package login;

import java.awt.Color;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;

public class AdminRegistration {

	private JFrame frame;
	private JTextField name;
	private JPasswordField pass;
    private JLabel lbl_adminReg;
    private JLabel lbl_uname;
    private JLabel lbl_pwd;
    private JButton reg;
    private JDialog success;
	
	public static Connection con;

    String driverclass = "com.mysql.cj.jdbc.Driver";
    String connectionURL = "jdbc:mysql://localhost:3306/AdmissionSystem";
    String username = "root";
    String password = "password";
    
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		new AdminRegistration();
	}

	
	public AdminRegistration() throws ClassNotFoundException, SQLException {
		frame = new JFrame();
        addTextFields();
        addLabels();
        addButtons();
        frame.setSize(500, 400);
        frame.getContentPane();
        frame.getContentPane().setLayout(null);   
        frame.getContentPane().setBackground(Color.LIGHT_GRAY);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);        

        Class.forName(driverclass);
        con = DriverManager.getConnection(connectionURL, username, password);
	}
	
	private void addTextFields() {
        name = new JTextField();
        name.setBounds(171, 118, 275, 25);
        frame.getContentPane().add(name);
        
        pass = new JPasswordField();
        pass.setBounds(171, 169, 275, 25);
        frame.getContentPane().add(pass);
    }
	
	private void addLabels() {
		        
        lbl_adminReg = new JLabel("Admin Registration Page");
        lbl_adminReg.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_adminReg.setBounds(157, 38, 165, 19);
        frame.getContentPane().add(lbl_adminReg);
        
        lbl_uname = new JLabel("Username");
        lbl_uname.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_uname.setBounds(44, 121, 85, 19);
        frame.getContentPane().add(lbl_uname);
        
        lbl_pwd = new JLabel("Password");
        lbl_pwd.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_pwd.setBounds(44, 170, 85, 19);
        frame.getContentPane().add(lbl_pwd);
        
	}

    private void addButtons() {
        reg = new JButton("Register");
        reg.setBounds(201, 237, 90, 43);
        reg.addActionListener(e -> {
            String username = name.getText();
            @SuppressWarnings("deprecation")
			String password = pass.getText();
            try {
                PreparedStatement ps = con.prepareStatement("insert into administrator(username,pass) values(?,?)");
                ps.setString(1, username);
                ps.setString(2, password);
                ps.execute();
                success = new JDialog(frame , "Status", true);
                success.setLayout(new FlowLayout());
                success.setSize(250,75);
                success.add( new JLabel("Registered Successfully!"));  
                success.setVisible(true); 
                if(success.getDefaultCloseOperation() == 1) {
                    new Login();
                }
            }
            catch (SQLException e1) {
                e1.printStackTrace();
            } 
            catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
            
        });
                
        frame.getContentPane().add(reg);
    }
}
