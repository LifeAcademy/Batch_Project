package login;

import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Start {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		new Start();
	}

	
	public Start() throws ClassNotFoundException, SQLException {
		JFrame frame = new JFrame("University Admission System");
	    frame.setSize(800, 750);
	    
	    ImageIcon img= new ImageIcon(new ImageIcon("res/Univ.jpeg").getImage().getScaledInstance(800, 750, 100)); 
	    JLabel lbl = new JLabel(img); 
		
	    frame.setResizable(false);
	    frame.add(lbl);
	    frame.setVisible(true);

	    try {
			Thread.sleep(6000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		frame.setVisible(false);
		new Login();
	}

}
