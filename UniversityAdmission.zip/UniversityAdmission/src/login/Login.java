package login;

import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import admin.Admin;
import register.Registration;

import java.awt.Color;
import javax.swing.JPasswordField;

//import p1.Register;
//import p1.Admin;

public class Login {

	public static JFrame frame;
    private JTextField name;
    
    private JLabel lbl_title;
    private JLabel lbl_login;
    private JLabel lbl_uname;
    private JLabel lbl_pwd;
    private JButton login;
    private JButton new_user;
    private JFrame stuLogin;
    private JDialog fail;
    public static Connection con;

    String driverclass = "com.mysql.cj.jdbc.Driver";
    String connectionURL = "jdbc:mysql://localhost:3306/AdmissionSystem";
    String username = "root";
    String password = "password";
    private JPasswordField pass;


	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		new Login();

	}

	public Login() throws ClassNotFoundException, SQLException {
		frame = new JFrame();
        addTextField();
        addLabels();
        addButtons();
        frame.setTitle("Login");
        frame.setSize(500, 400);
        frame.getContentPane();
        frame.getContentPane().setBackground(Color.LIGHT_GRAY);
        frame.getContentPane().setLayout(null);  
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        

        Class.forName(driverclass);
        con = DriverManager.getConnection(connectionURL, username, password);
	}
	
	private void addTextField() {
        name = new JTextField();
        name.setBounds(171, 118, 275, 25);
        frame.add(name);
        
        pass = new JPasswordField();
        pass.setBounds(171, 169, 275, 25);
        frame.getContentPane().add(pass);
    }
	
	private void addLabels() {
		lbl_title = new JLabel("University Admission System");
        lbl_title.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_title.setBounds(151, 22, 179, 25);
        frame.getContentPane().add(lbl_title);
        
        lbl_login = new JLabel("Login Page");
        lbl_login.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_login.setBounds(201, 58, 85, 19);
        frame.getContentPane().add(lbl_login);
        
        lbl_uname = new JLabel("Username");
        lbl_uname.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_uname.setBounds(44, 121, 85, 19);
        frame.getContentPane().add(lbl_uname);
        
        lbl_pwd = new JLabel("Password");
        lbl_pwd.setHorizontalAlignment(SwingConstants.CENTER);
        lbl_pwd.setBounds(44, 170, 85, 19);
        frame.getContentPane().add(lbl_pwd);
        
	}

    @SuppressWarnings("deprecation")
	private void addButtons() {
        login = new JButton("Login");
        login.setBounds(201, 237, 90, 43);
        
        login.addActionListener(e -> {
            String username = name.getText();
            String password = pass.getText();

            checkLogin(username, password);
        });
        
        new_user = new JButton("New User");
        new_user.setBounds(327, 237, 90, 43);
        new_user.addActionListener(e -> {
        	Registration.open();
        });  
        
        frame.getContentPane().add(new_user);
        frame.getContentPane().add(login);
    }
    
    private void checkLogin(String username, String password) {
        try {
            PreparedStatement ps1 = con.prepareStatement("select id,username,pass from registration where username=? and pass=?");
            PreparedStatement ps2 = con.prepareStatement("select username,pass from administrator where username=? and pass=?");
            ps1.setString(1, username);
            ps1.setString(2, password);
            ps2.setString(1, username);
            ps2.setString(2, password);
            ResultSet result1 = ps1.executeQuery();
            ResultSet result2 = ps2.executeQuery();
            
            if(result1.next()) {
            	int u_id=result1.getInt(1);
            	String u_name=result1.getString(2);
            	
            	stuLogin=new JFrame();
                stuLogin.setSize(500, 400);
                stuLogin.getContentPane().setBackground(Color.pink);
                
                try {
                  
                	PreparedStatement stmt=con.prepareStatement("select d.department_id,d.department_name,d.faculty_incharge,sel.selected from department d"
                			+ " join registration reg on reg.department_name=d.department_name join selection sel on sel.id=reg.id "
                			+ "where reg.id=(select distinct r.id from registration r join selection s on r.id=s.id where r.id=?)"); 
                	stmt.setInt(1, u_id);
                	ResultSet res=stmt.executeQuery();
                	
                	
                	if(res.next() && res.getString(4).equals("T")) {
                		stuLogin.setTitle("Student Login");
                		stuLogin.getContentPane().add(new JLabel("Congratulations "+u_name+"! You are selected in the admission process..."), SwingConstants.CENTER);
                		stuLogin.getContentPane().add(new JLabel("Department and Faculty Details: "));
                		stuLogin.getContentPane().add(new JLabel("Department id: "+res.getInt(1)+" | "));
                		stuLogin.getContentPane().add(new JLabel("Department Name: "+res.getString(2)+" | "));
                		stuLogin.getContentPane().add(new JLabel("Faculty Incharge for "+res.getString(2)+ ": "+res.getString(3)));
                	                    		
                	}
                	else {
                		stuLogin.setTitle("Student Login");
                		stuLogin.getContentPane().add(new JLabel("Sorry "+u_name+"! You are not selected in the admission process..."));
                	    stuLogin.getContentPane().add(new JLabel("You are not meeting the cutoff criteria for the course you have applied."));
                	    stuLogin.getContentPane().add(new JLabel("You can apply for the other courses available within the Registration ends."));              		
                		
                	}
                	
                }
                catch(SQLException e1) {
                    e1.printStackTrace();           	
                }
                stuLogin.getContentPane().setLayout(new FlowLayout());
                stuLogin.setVisible(true);
                stuLogin.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
            }
            else if(result2.next()) {
            	System.out.println("Admin Login");
            	Admin.open();
            	frame.setVisible(false);
            }
            else {            	
                fail = new JDialog(stuLogin , "Status", true);
                fail.getContentPane().setLayout(new FlowLayout());
                fail.setSize(500, 150);
                fail.getContentPane().add(new JLabel("You are not a registered user!.. \nPlease register by clicking 'New User' in login page"));  
                fail.setVisible(true);               
            }
           
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
    }


}
