package admin;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

import com.toedter.calendar.JDateChooser;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Admin extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldCS;
	private JTextField textFieldBio;
	private JTextField textFieldEEE;
	private JTextField textFieldML;
	private JTable table;
	private JButton btnList;
	
	JDateChooser fromDateInput;
	JDateChooser toDateInput;

	private Connection con;
	private String driverclass = "com.mysql.cj.jdbc.Driver";
	private String connectionURL = "jdbc:mysql://localhost:3306/AdmissionSystem";
	private String username = "root";
	private String password = "password";

	public static void open() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin frame = new Admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void makeConnection() {
		try {
			Class.forName(driverclass);
			con = DriverManager.getConnection(connectionURL, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void closeConnection() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private Admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.setBackground(Color.lightGray);

		textFieldCS = new JTextField();
		textFieldCS.setBounds(63, 102, 86, 20);
		contentPane.add(textFieldCS);
		textFieldCS.setColumns(10);

		textFieldBio = new JTextField();
		textFieldBio.setBounds(63, 155, 86, 20);
		contentPane.add(textFieldBio);
		textFieldBio.setColumns(10);

		textFieldEEE = new JTextField();
		textFieldEEE.setBounds(63, 210, 86, 20);
		contentPane.add(textFieldEEE);
		textFieldEEE.setColumns(10);

		textFieldML = new JTextField();
		textFieldML.setBounds(63, 267, 86, 20);
		contentPane.add(textFieldML);
		textFieldML.setColumns(10);
		
		toDateInput = new JDateChooser();
		toDateInput.setDateFormatString("yyyy/MM/dd");
		toDateInput.setBounds(119, 355, 99, 20);
		toDateInput.setVisible(true);
		contentPane.add(toDateInput);

		fromDateInput = new JDateChooser();
		fromDateInput.setDateFormatString("yyyy/MM/dd");
		fromDateInput.setBounds(10, 355, 99, 20);
		fromDateInput.setVisible(true);
		contentPane.add(fromDateInput);
		

		btnList = new JButton("List");
		btnList.setBounds(60, 449, 89, 23);
		contentPane.add(btnList);

		JLabel lblNewLabel = new JLabel("CS");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(82, 77, 46, 14);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Bio");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(82, 133, 46, 14);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("EEE");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(82, 186, 46, 14);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("ML");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(82, 242, 46, 14);
		contentPane.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("From");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(29, 330, 46, 14);
		contentPane.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("To");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(138, 330, 46, 14);
		contentPane.add(lblNewLabel_5);
		addActionListeners();
	}

	public void addActionListeners() {
		btnList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				makeConnection();
				truncateSelectionTable();
				select();
				processNotSelected();
				print();
				closeConnection();
			}
		});
	}
	
	//print values to a table from database
	private void print() {
		try {
			PreparedStatement ps1 = con.prepareStatement("select count(*) from selection;");
			ResultSet res1 = ps1.executeQuery();
			int count = 0;
			if(res1.next()) {
				count = res1.getInt(1);
			}
			
			PreparedStatement ps2 = con.prepareStatement("select registration.id, registration.first_name, registration.phone_number, registration.email, registration.total_score, registration.department_name, selection.selected from selection inner join registration where selection.id = registration.id;");
			ResultSet res2 = ps2.executeQuery();
			
			String data[][] = new String[count][7];
			
			int index = 0;
			while(res2.next()) {
				data[index][0] = String.valueOf(res2.getInt(1));
				data[index][1] = res2.getString(2);
				data[index][2] = res2.getString(3);
				data[index][3] = res2.getString(4);
				
				data[index][4] = String.valueOf(res2.getInt(5));
				data[index][5] = res2.getString(6);
				data[index][6] = res2.getString(7);
				index += 1;
			}
			
			String column[]={"ID", "FIRST_NAME", "PHONE_NUMBER", "EMAIL","TOTAL_SCORE", "DEPARTMENT", "SELECTED"}; 
			
			table = new JTable(data, column);
			JScrollPane scrollPane = new JScrollPane(table);
			scrollPane.setBounds(221, 11, 653, 539);
			contentPane.add(scrollPane);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// update table and insert back into database
		table.getModel().addTableModelListener(new TableModelListener() {
			public void tableChanged(TableModelEvent e) {
				makeConnection();
				int row = e.getFirstRow();
				int id = Integer.parseInt((String)table.getValueAt(row, 0));
				String first_name = (String)table.getValueAt(row, 1);
				String phone_number = (String)table.getValueAt(row, 2);
				String email = (String)table.getValueAt(row, 3);
				int total_score = Integer.parseInt((String)table.getValueAt(row, 4));
				String department = (String)table.getValueAt(row, 5);
				String selected = (String)table.getValueAt(row, 6);
				try {
					PreparedStatement ps = con.prepareStatement("update registration set first_name = ?, phone_number = ?, email = ?, total_score = ?, department_name = ? where id = ?;");
					ps.setString(1, first_name);
					ps.setString(2, phone_number);
					ps.setString(3, email);
					ps.setInt(4, total_score);
					ps.setString(5, department);
					ps.setInt(6, id);
					ps.execute();
					PreparedStatement ps2 = con.prepareStatement("update selection set selected = ? where id = ?;");
					ps2.setString(1, selected);
					ps2.setInt(2, id);
					ps2.execute();
				} catch (SQLException e2) {
					e2.printStackTrace();
				}
				
				closeConnection();
			}
		});
	}
	
	// clear selection table
	private void truncateSelectionTable() {
		try {
			PreparedStatement ps = con.prepareStatement("truncate table selection");
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//list of students who are not selected
	private void processNotSelected() {
		try {
			PreparedStatement ps = con.prepareStatement("insert into selection select registration.id, 'F' from registration where id not in(select selection.id from selection inner join registration where selection.id = registration.id);");
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//list of students who are selected query
	private String getQuerySelection() {
		return "insert into selection select registration.id, 'T' from registration where department_name = ? and \r\n" + 
				"cast(date_of_registration as datetime) >= cast(? as datetime) and \r\n" + 
				"cast(date_of_registration as datetime) <= cast(? as datetime)\r\n" + 
				"order by total_score desc limit ?;";
	}
	
	private void setPreparedStatement(int limit, String course) {	
		String fromDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(fromDateInput.getDate());
		String toDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(toDateInput.getDate());
		
		try {
			PreparedStatement ps = con.prepareStatement(getQuerySelection());
			ps.setString(1, course);
			ps.setString(2, fromDate);
			ps.setString(3, toDate);
			ps.setInt(4, limit);
			ps.execute();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
	}
	
	//list of students who are selected
	private void select() {
		setPreparedStatement(Integer.parseInt(textFieldCS.getText()), "CS");
		setPreparedStatement(Integer.parseInt(textFieldBio.getText()), "Bio");
		setPreparedStatement(Integer.parseInt(textFieldEEE.getText()), "EEE");
		setPreparedStatement(Integer.parseInt(textFieldML.getText()), "ML");
	}
}
