package register;

import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;
import com.toedter.calendar.JDateChooser;
import javax.swing.border.BevelBorder;
import java.awt.Cursor;

public class Registration {

	private JFrame frame;
	private JTextField first_name;
	private JTextField last_name;
	private JTextField age;
	private JTextField mother_name;
	private JTextField father_name;
	private JTextField loc;
	private JTextField email;
	private JTextField user_name;
	private JPasswordField pass;
	private JTextField physics;
	private JTextField chemistry;
	private JTextField maths;
	private JTextField biology;
	private JTextField english;
	private JTextField textField_21;
	private JTextField total;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JRadioButton female;
	private JRadioButton male;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void open() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public Registration() throws ClassNotFoundException, SQLException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */

	private void initialize() throws ClassNotFoundException, SQLException {
		frame = new JFrame();
		frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 681, 556);
		frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("First Name\r\n");
		lblNewLabel.setBounds(10, 77, 98, 14);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setBounds(10, 105, 66, 14);
		frame.getContentPane().add(lblLastName);

		first_name = new JTextField();
		first_name.setBackground(Color.CYAN);
		first_name.setBounds(110, 74, 180, 20);
		frame.getContentPane().add(first_name);
		first_name.setColumns(10);

		JLabel lblAge = new JLabel("Age");
		lblAge.setBounds(10, 137, 46, 14);
		frame.getContentPane().add(lblAge);

		last_name = new JTextField();
		last_name.setBackground(Color.CYAN);
		last_name.setBounds(110, 102, 180, 20);
		frame.getContentPane().add(last_name);
		last_name.setColumns(10);

		JLabel lblMothersName = new JLabel("Mother's Name");
		lblMothersName.setBounds(10, 168, 86, 14);
		frame.getContentPane().add(lblMothersName);

		age = new JTextField();
		age.setBackground(Color.CYAN);
		age.setBounds(110, 134, 180, 20);
		frame.getContentPane().add(age);
		age.setColumns(10);

		JLabel lblFathersName = new JLabel("Father's Name");
		lblFathersName.setBounds(10, 202, 98, 14);
		frame.getContentPane().add(lblFathersName);

		mother_name = new JTextField();
		mother_name.setBackground(Color.CYAN);
		mother_name.setBounds(110, 165, 180, 20);
		frame.getContentPane().add(mother_name);
		mother_name.setColumns(10);

		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(10, 227, 46, 14);
		frame.getContentPane().add(lblGender);

		male = new JRadioButton("Male");
		/*
		 * male.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent e) { if(male.isSelected()) {
		 * female.setSelected(false); } } });
		 */
		buttonGroup.add(male);
		male.setBackground(Color.CYAN);
		male.setBounds(110, 223, 52, 23);
		frame.getContentPane().add(male);

		female = new JRadioButton("Female");
		/*
		 * female.addActionListener(new ActionListener() { public void
		 * actionPerformed(ActionEvent e) { if(female.isSelected()) {
		 * male.setSelected(false); } } });
		 */

		buttonGroup.add(female);
		female.setBackground(Color.CYAN);
		female.setBounds(199, 223, 91, 23);
		frame.getContentPane().add(female);

		JLabel lblDateOfBirth = new JLabel("Date of Birth");
		lblDateOfBirth.setBounds(10, 255, 98, 14);
		frame.getContentPane().add(lblDateOfBirth);

		father_name = new JTextField();
		father_name.setBackground(Color.CYAN);
		father_name.setBounds(110, 199, 180, 20);
		frame.getContentPane().add(father_name);
		father_name.setColumns(10);

		JLabel lblContactNumber = new JLabel("Registration Date");
		lblContactNumber.setBounds(10, 284, 98, 14);
		frame.getContentPane().add(lblContactNumber);

		JLabel lblAlternateContactNumber = new JLabel("Email ID");
		lblAlternateContactNumber.setBounds(10, 351, 132, 14);
		frame.getContentPane().add(lblAlternateContactNumber);

		JLabel lblPassword = new JLabel("Username");
		lblPassword.setBounds(10, 376, 86, 14);
		frame.getContentPane().add(lblPassword);

		loc = new JTextField();
		loc.setBackground(Color.CYAN);
		loc.setBounds(110, 315, 180, 20);
		frame.getContentPane().add(loc);
		loc.setColumns(10);

		JLabel lblPassword_1 = new JLabel("Password");
		lblPassword_1.setBounds(10, 407, 86, 14);
		frame.getContentPane().add(lblPassword_1);

		email = new JTextField();
		email.setBackground(Color.CYAN);
		email.setBounds(110, 346, 180, 20);
		frame.getContentPane().add(email);
		email.setColumns(10);

		JLabel lblLocation = new JLabel("Location");
		lblLocation.setBounds(10, 318, 86, 14);
		frame.getContentPane().add(lblLocation);

		user_name = new JTextField();
		user_name.setBackground(Color.CYAN);
		user_name.setBounds(110, 373, 180, 20);
		frame.getContentPane().add(user_name);
		user_name.setColumns(10);

		JLabel lblPersonalDetails = new JLabel("Personal Details");
		lblPersonalDetails.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPersonalDetails.setBounds(10, 49, 280, 14);
		frame.getContentPane().add(lblPersonalDetails);

		JLabel lblStudentRegistrationForm = new JLabel("Student Registration Form");
		lblStudentRegistrationForm.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblStudentRegistrationForm.setHorizontalAlignment(SwingConstants.CENTER);
		lblStudentRegistrationForm.setBounds(161, 22, 300, 27);
		frame.getContentPane().add(lblStudentRegistrationForm);

		JLabel lblEducationalDetails = new JLabel("Educational Details");
		lblEducationalDetails.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblEducationalDetails.setBounds(324, 49, 276, 14);
		frame.getContentPane().add(lblEducationalDetails);

		pass = new JPasswordField();
		pass.setBackground(Color.CYAN);
		pass.setBounds(110, 404, 180, 20);
		frame.getContentPane().add(pass);

		JLabel lblNewLabel_2_1 = new JLabel("Physics\r\n");
		lblNewLabel_2_1.setBounds(324, 77, 46, 14);
		frame.getContentPane().add(lblNewLabel_2_1);

		JLabel lblNewLabel_2_1_1 = new JLabel("Physics\r\n");
		lblNewLabel_2_1_1.setBounds(638, -150, 46, 14);
		frame.getContentPane().add(lblNewLabel_2_1_1);

		JLabel lblNewLabel_3_1 = new JLabel("Chemistry");
		lblNewLabel_3_1.setBounds(324, 105, 86, 14);
		frame.getContentPane().add(lblNewLabel_3_1);

		JLabel lblNewLabel_1_1 = new JLabel("Maths");
		lblNewLabel_1_1.setBounds(324, 137, 98, 14);
		frame.getContentPane().add(lblNewLabel_1_1);

		JLabel lblNewLabel_4_1 = new JLabel("Biology");
		lblNewLabel_4_1.setBounds(324, 168, 46, 14);
		frame.getContentPane().add(lblNewLabel_4_1);

		JLabel lblNewLabel_5_1 = new JLabel("English");
		lblNewLabel_5_1.setBounds(324, 202, 46, 14);
		frame.getContentPane().add(lblNewLabel_5_1);

		JLabel cs = new JLabel("Computer Science");
		cs.setBounds(324, 227, 152, 14);
		frame.getContentPane().add(cs);

		JLabel lblNewLabel_7_1 = new JLabel("Total Marks");
		lblNewLabel_7_1.setBounds(324, 255, 79, 14);
		frame.getContentPane().add(lblNewLabel_7_1);

		JLabel lblNewLabel_7_1_1 = new JLabel("Total Marks");
		lblNewLabel_7_1_1.setBounds(634, -125, 79, 14);
		frame.getContentPane().add(lblNewLabel_7_1_1);

		physics = new JTextField();
		physics.setText("0");
		physics.setBackground(Color.CYAN);
		physics.setColumns(10);
		physics.setBounds(430, 74, 180, 20);
		frame.getContentPane().add(physics);

		chemistry = new JTextField();
		chemistry.setText("0");
		chemistry.setBackground(Color.CYAN);
		chemistry.setColumns(10);
		chemistry.setBounds(430, 102, 180, 20);
		frame.getContentPane().add(chemistry);

		maths = new JTextField();
		maths.setText("0");
		maths.setBackground(Color.CYAN);
		maths.setColumns(10);
		maths.setBounds(430, 134, 180, 20);
		frame.getContentPane().add(maths);

		biology = new JTextField();
		biology.setText("0");
		biology.setSelectionColor(Color.CYAN);
		biology.setBackground(Color.CYAN);
		biology.setColumns(10);
		biology.setBounds(430, 165, 180, 20);
		frame.getContentPane().add(biology);

		english = new JTextField();
		english.setText("0");
		english.setBackground(Color.CYAN);
		english.setColumns(10);
		english.setBounds(430, 199, 180, 20);
		frame.getContentPane().add(english);

		textField_21 = new JTextField();
		textField_21.setText("0");
		textField_21.setBackground(Color.CYAN);
		textField_21.setColumns(10);
		textField_21.setBounds(430, 224, 180, 20);
		frame.getContentPane().add(textField_21);

		total = new JTextField();
		total.setText("0");
		total.setBackground(Color.CYAN);
		total.setColumns(10);
		total.setBounds(430, 252, 180, 20);
		frame.getContentPane().add(total);

		JLabel lblNewLabel_8_1 = new JLabel("Department");
		lblNewLabel_8_1.setBounds(324, 284, 86, 14);
		frame.getContentPane().add(lblNewLabel_8_1);

		JComboBox<String> department = new JComboBox<String>();
		department.setBackground(Color.CYAN);
		department.setModel(new DefaultComboBoxModel<String>(new String[] { "", "CS", "Bio", "EEE", "ML" }));
		department.setBounds(430, 281, 180, 20);
		frame.getContentPane().add(department);

		JButton btnRegister = new JButton("Register");
		btnRegister.setBackground(Color.GREEN);
		btnRegister.setBounds(283, 484, 89, 23);
		frame.getContentPane().add(btnRegister);

		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		dateChooser.setDateFormatString("dd/MM/yyyy");
		dateChooser.getCalendarButton().setBackground(Color.CYAN);
		dateChooser.setForeground(Color.CYAN);
		dateChooser.setBackground(Color.CYAN);
		dateChooser.setBounds(110, 253, 180, 20);
		frame.getContentPane().add(dateChooser);

		JDateChooser dateChooser_1 = new JDateChooser();
		dateChooser_1.getCalendarButton().setBackground(Color.CYAN);
		dateChooser_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		dateChooser_1.setBackground(Color.CYAN);
		dateChooser_1.setDateFormatString("dd/MM/yyyy");
		dateChooser_1.setBounds(110, 284, 180, 20);
		frame.getContentPane().add(dateChooser_1);

		JLabel lblContactNo = new JLabel("Contact No");
		lblContactNo.setBounds(10, 438, 66, 14);
		frame.getContentPane().add(lblContactNo);

		textField = new JTextField();
		textField.setBackground(Color.CYAN);
		textField.setBounds(110, 435, 180, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		JLabel label = new JLabel("New label");
		label.setFont(new Font("Tahoma", Font.BOLD, 11));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(317, 11, 86, 14);
		frame.getContentPane().add(label);

		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(231, 11, 72, 14);
		frame.getContentPane().add(lblNewLabel_1);

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		lblNewLabel_1.setText(formatter.format(date));
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {

			@Override
			public void run() {
				String string = new SimpleDateFormat("HH:mm:ss").format(new Date());
				label.setText(string);
			}

		}, 0, 1000);

		// Database Connectivity
		String driverclass = "com.mysql.cj.jdbc.Driver";
		String connectionURL = "jdbc:mysql://localhost:3306/AdmissionSystem";
		String username = "root";
		String password = "password";

		Class.forName(driverclass);

		Connection con = DriverManager.getConnection(connectionURL, username, password);

		btnRegister.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				try {
					// Personal Details
					String fn = first_name.getText();
					String ln = last_name.getText();
					int Age = Integer.parseInt(age.getText());
					String faname = father_name.getText();
					String moname = mother_name.getText();

					// System.out.println(gen);
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
					String dob = dateFormat.format((dateChooser.getDate()));
					String dor = dateFormat.format((dateChooser_1.getDate()));
					
					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
					LocalDateTime now = LocalDateTime.now();  
					String nowDate = dtf.format(now);
					if(!dor.equals(nowDate)) {
						dor = nowDate;
					}
					
					String location = loc.getText();
					String mail = email.getText();
					String uname = user_name.getText();
					String pw = new String(pass.getPassword());
					String pno = textField.getText();

					String gen = "";
					if (female.isSelected()) {
						gen = "F";
					} else if (male.isSelected()) {
						gen = "M";
					}
					// Educational Details
					int phy = Integer.parseInt(physics.getText());
					int chem = Integer.parseInt(chemistry.getText());
					int math = Integer.parseInt(maths.getText());
					int bio = Integer.parseInt(biology.getText());
					int eng = Integer.parseInt(english.getText());
					int cs = Integer.parseInt(textField_21.getText());
					int ts = Integer.parseInt(total.getText());
					int tot = phy + chem + math + bio + eng + cs;
					if(ts != tot) {
						ts = tot;
						total.setText(String.valueOf(tot));
					}
					String dept = department.getSelectedItem().toString();

					// Inserting Values into Database
					PreparedStatement ps;
					ps = con.prepareStatement("insert into registration() values(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					ps.setString(1, fn);
					ps.setString(2, ln);
					ps.setInt(3, Age);
					ps.setString(4, gen);
					ps.setString(5, dob);
					ps.setString(6, dor);
					ps.setString(7, pno);
					ps.setString(8, location);
					ps.setString(9, mail);
					ps.setString(10, uname);
					ps.setString(11, pw);
					ps.setString(12, faname);
					ps.setString(13, moname);

					ps.setInt(14, math);
					ps.setInt(15, phy);
					ps.setInt(16, chem);
					ps.setInt(17, eng);
					ps.setInt(18, cs);
					ps.setInt(19, bio);

					ps.setInt(20, ts);
					ps.setString(21, dept);

					ps.execute();

					JOptionPane.showMessageDialog(frame, "Registration Successfull");
				} catch (NumberFormatException | NullPointerException ex) {
					exceptions();
				} catch (SQLException e1) {
					if(e1.getErrorCode() == 1062) {
						userExists();
					}
				} 
			}
		});
	}
	
	private void userExists() {
		JDialog exceptions = new JDialog(frame , "Status", true);
        exceptions.getContentPane().setLayout(new FlowLayout());
        exceptions.setSize(500, 150);
        exceptions.getContentPane().add(new JLabel("The user you have entered already exists please try another username!"));  
        exceptions.setVisible(true); 
	}
	
	private void exceptions() {
		JDialog exceptions = new JDialog(frame , "Status", true);
        exceptions.getContentPane().setLayout(new FlowLayout());
        exceptions.setSize(500, 150);
        exceptions.getContentPane().add(new JLabel("Please enter correct details!"));  
        exceptions.setVisible(true); 
	}
}