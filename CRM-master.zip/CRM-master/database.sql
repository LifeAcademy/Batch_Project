
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('ADMIN','Admin@123'),('Deeepsh','Deepesh@123'),('Vishal','Vishal@123'),('Guru','Guru@123');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `ID` int(11) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Count` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Keyboard',113),(2,'Mouse',69),(3,'Screen',55),(4,'Ram',15),(5,'Speaker',50),(6,'rom',0),(7,'chip',50),(8,'tv',50),(9,'lcd',50),(33,'ROM',200);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_sold`
--

DROP TABLE IF EXISTS `products_sold`;

CREATE TABLE `products_sold` (
  `Customer_name` varchar(30) DEFAULT NULL,
  `Product_id` int(11) DEFAULT NULL,
  `warranty` int(11) DEFAULT NULL,
  `product_name` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--

LOCK TABLES `products_sold` WRITE;
/*!40000 ALTER TABLE `products_sold` DISABLE KEYS */;
INSERT INTO `products_sold` VALUES ('Anmol',1,50,'Mouse',NULL),('Parbhat',1,25,'Mouse',NULL),('papa',2,60,'Keyboard',NULL),('nri',1,50,'Mouse',NULL),('Anmol',1,50,'Mouse\"2014-12-02 01:07:43',NULL),('md',1,50,'chd','2014-12-02'),('ps',1,20,'Mouse','2014-12-03'),('appaji',1,20,'Mouse','2014-12-03'),('1',1,20,'key','2014-12-03'),('nope',1,50,'Keyboard','2014-12-03'),('nopei',1,50,'Keyboard','2014-12-03'),('real',6,2,'Keyboard','2014-12-03'),('15',2,50,'Mouse','2014-12-03'),('ISO-9001:2008 certified',1,33,'Keyboard','2014-12-03');
/*!40000 ALTER TABLE `products_sold` ENABLE KEYS */;
UNLOCK TABLES;
